# Student-Managment-System
File Handling, User Authentication, User Interface, Database Integration 
• A student management system written in Python for my Introduction to Computing Class.
• Handles 3 types of users: student, faculty, and admin.
• All data was reported in CSV format and operated by different algorithms specific to each use.
Login info you need to get started using our student system management:
-For Admin page:
	ID :Admin
	Password:Admin
-For student page:
	ID :S00(number from 00 to 97)
	Password :EUI@ID
-For Faculty page:
	ID:F00(number from 01 to 08)
	Password:EUI@ID
* Note that different faculty ID gives you different access to different courses

